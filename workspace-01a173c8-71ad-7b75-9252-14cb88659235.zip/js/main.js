/* NOVA Living — storefront interactions */
(() => {
  'use strict';
  const DB = window.InventoryDB;
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const escapeHTML = value => String(value ?? '').replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
  const icon = id => `<svg aria-hidden="true"><use href="#${id}"></use></svg>`;

  // Theme
  const themeButton = $('.theme-toggle');
  const applyTheme = theme => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem('nova_theme', theme);
    themeButton?.querySelector('use')?.setAttribute('href', theme === 'dark' ? '#i-moon' : '#i-sun');
    themeButton?.setAttribute('aria-label', theme === 'dark' ? 'Activează tema luminoasă' : 'Activează tema întunecată');
  };
  applyTheme(localStorage.getItem('nova_theme') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
  themeButton?.addEventListener('click', () => applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));

  // Header & mobile navigation
  const header = $('#siteHeader');
  const onScroll = () => header?.classList.toggle('is-sticky', scrollY > 44);
  onScroll(); addEventListener('scroll', onScroll, { passive: true });
  const menuToggle = $('.menu-toggle');
  const mobileMenu = $('.mobile-menu');
  function setMenu(open) {
    menuToggle?.setAttribute('aria-expanded', String(open));
    menuToggle?.setAttribute('aria-label', open ? 'Închide meniul' : 'Deschide meniul');
    mobileMenu?.classList.toggle('open', open); mobileMenu?.setAttribute('aria-hidden', String(!open));
    header?.classList.toggle('menu-open', open); document.body.classList.toggle('is-locked', open);
  }
  menuToggle?.addEventListener('click', () => setMenu(menuToggle.getAttribute('aria-expanded') !== 'true'));
  $$('.mobile-menu a').forEach(link => link.addEventListener('click', () => setMenu(false)));

  // Reveal & counters
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const animateCounter = element => {
    if (element.dataset.done) return; element.dataset.done = 'true';
    const target = Number(element.dataset.count); const duration = 1300; const start = performance.now();
    const tick = now => { const progress = Math.min(1, (now - start) / duration); const eased = 1 - Math.pow(1 - progress, 3); element.textContent = Math.round(target * eased); if (progress < 1) requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
  };
  if ('IntersectionObserver' in window && !reducedMotion) {
    const revealObserver = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('is-visible'); $$('[data-count]', entry.target).forEach(animateCounter); revealObserver.unobserve(entry.target); }
    }), { threshold: .13 });
    $$('.reveal').forEach(element => revealObserver.observe(element));
    const counterObserver = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { animateCounter(entry.target); counterObserver.unobserve(entry.target); } }), { threshold: .5 });
    $$('[data-count]').forEach(element => counterObserver.observe(element));
  } else { $$('.reveal').forEach(el => el.classList.add('is-visible')); $$('[data-count]').forEach(el => { el.textContent = el.dataset.count; }); }

  // Shared toast
  function toast(message, type = 'success') {
    const stack = $('#toastStack'); if (!stack) return;
    const item = document.createElement('div'); item.className = `toast ${type}`; item.innerHTML = `<p>${escapeHTML(message)}</p>`; stack.append(item);
    setTimeout(() => { item.classList.add('is-leaving'); setTimeout(() => item.remove(), 320); }, 3400);
  }
  window.novaToast = toast;

  // Product catalogue
  const state = { category: 'all', query: '', sort: 'featured', limit: 8 };
  const getCategory = id => DB.getCategory(id) || { name: 'Colecție', color: '#7467eb' };
  const stockText = product => product.quantity <= 0 ? 'Stoc epuizat' : product.quantity <= product.minStock ? `Ultimele ${product.quantity} bucăți` : 'În stoc, livrare rapidă';
  const productCard = product => {
    const category = getCategory(product.categoryId); const status = DB.getStockStatus(product);
    return `<article class="product-card" data-product-id="${escapeHTML(product.id)}">
      <div class="product-media">
        <img src="${product.image}" alt="${escapeHTML(product.name)}" loading="lazy">
        ${product.featured ? '<span class="product-tag">NOVA pick</span>' : status === 'low' ? '<span class="product-tag low">Stoc limitat</span>' : ''}
        <button class="wishlist" type="button" aria-label="Adaugă la favorite" data-wishlist>${icon('i-heart')}</button>
        <button class="quick-add" type="button" data-add-cart="${escapeHTML(product.id)}" ${status === 'out' ? 'disabled' : ''}>${icon('i-bag')} ${status === 'out' ? 'Indisponibil' : 'Adaugă în coș'}</button>
      </div>
      <div class="product-info"><span class="product-category">${escapeHTML(category.name)}</span><div class="product-name-price"><h3>${escapeHTML(product.name)}</h3><strong>${DB.formatCurrency(product.price)}</strong></div><span class="product-stock ${status}"><i></i>${stockText(product)}</span></div>
    </article>`;
  };

  function availableProducts() { return DB.getProducts().filter(product => product.quantity > 0); }
  function filteredProducts() {
    let products = availableProducts().filter(product => state.category === 'all' || product.categoryId === state.category).filter(product => `${product.name} ${product.sku} ${product.description}`.toLocaleLowerCase('ro').includes(state.query.toLocaleLowerCase('ro')));
    products.sort((a, b) => state.sort === 'price-asc' ? a.price - b.price : state.sort === 'price-desc' ? b.price - a.price : state.sort === 'name' ? a.name.localeCompare(b.name, 'ro') : Number(b.featured) - Number(a.featured) || b.sales - a.sales);
    return products;
  }
  function renderFeatured() {
    const root = $('#featuredProducts'); if (!root) return;
    const products = availableProducts().filter(item => item.featured).sort((a, b) => b.sales - a.sales).slice(0, 4);
    root.innerHTML = products.length ? products.map(productCard).join('') : emptyProductsHTML();
  }
  function emptyProductsHTML() { return '<div class="empty-state"><div class="empty-illustration"><span></span></div><h3>Colecția se pregătește</h3><p>Produsele vor apărea aici imediat ce sunt adăugate în stoc.</p></div>'; }
  function renderCategoryFilters() {
    const root = $('#categoryFilters'); if (!root) return;
    const categories = DB.getCategories();
    root.innerHTML = `<button class="filter-chip ${state.category === 'all' ? 'active' : ''}" data-category="all" type="button">Toate</button>${categories.map(category => `<button class="filter-chip ${state.category === category.id ? 'active' : ''}" data-category="${escapeHTML(category.id)}" type="button">${escapeHTML(category.name)}</button>`).join('')}`;
  }
  function renderCatalog() {
    const grid = $('#catalogGrid'); if (!grid) return;
    const all = filteredProducts(); const shown = all.slice(0, state.limit);
    grid.innerHTML = shown.map(productCard).join('');
    $('#resultCount').textContent = all.length; $('#catalogEmpty').hidden = all.length > 0;
    $('#loadMore').hidden = shown.length >= all.length;
  }
  function resetCatalog() { state.category = 'all'; state.query = ''; state.sort = 'featured'; state.limit = 8; if ($('#catalogSearch')) $('#catalogSearch').value = ''; if ($('#catalogSort')) $('#catalogSort').value = 'featured'; renderCategoryFilters(); renderCatalog(); }
  renderFeatured(); renderCategoryFilters(); renderCatalog();
  $('#categoryFilters')?.addEventListener('click', event => { const chip = event.target.closest('[data-category]'); if (!chip) return; state.category = chip.dataset.category; state.limit = 8; renderCategoryFilters(); renderCatalog(); });
  $('#catalogSearch')?.addEventListener('input', event => { state.query = event.target.value.trim(); state.limit = 8; renderCatalog(); });
  $('#catalogSort')?.addEventListener('change', event => { state.sort = event.target.value; renderCatalog(); });
  $('#loadMore')?.addEventListener('click', () => { state.limit += 8; renderCatalog(); });
  $('#resetFilters')?.addEventListener('click', resetCatalog); $('[data-reset-catalog]')?.addEventListener('click', resetCatalog);

  // Wishlist demo microinteraction
  document.addEventListener('click', event => {
    const wish = event.target.closest('[data-wishlist]'); if (!wish) return;
    wish.classList.toggle('active'); wish.setAttribute('aria-label', wish.classList.contains('active') ? 'Elimină de la favorite' : 'Adaugă la favorite');
    toast(wish.classList.contains('active') ? 'Produs salvat la favorite.' : 'Produs eliminat din favorite.');
  });

  // Cart
  const CART_KEY = 'nova_cart';
  let cart = (() => { try { return JSON.parse(localStorage.getItem(CART_KEY)) || []; } catch { return []; } })();
  const saveCart = () => { localStorage.setItem(CART_KEY, JSON.stringify(cart)); renderCart(); };
  function cartQuantity() { return cart.reduce((sum, item) => sum + item.quantity, 0); }
  function addToCart(productId) {
    const product = DB.getProduct(productId); if (!product || product.quantity <= 0) return toast('Produsul nu mai este disponibil.', 'error');
    const existing = cart.find(item => item.productId === productId); const current = existing?.quantity || 0;
    if (current >= product.quantity) return toast('Ai ajuns la cantitatea disponibilă în stoc.', 'error');
    if (existing) existing.quantity++; else cart.push({ productId, quantity: 1 });
    saveCart(); toast(`${product.name} a fost adăugat în coș.`); animateCartButton();
  }
  function changeCart(productId, delta) {
    const item = cart.find(entry => entry.productId === productId); const product = DB.getProduct(productId); if (!item) return;
    if (delta > 0 && item.quantity >= (product?.quantity || 0)) return toast('Nu mai avem alte bucăți disponibile.', 'error');
    item.quantity += delta; if (item.quantity <= 0) cart = cart.filter(entry => entry.productId !== productId); saveCart();
  }
  function renderCart() {
    cart = cart.filter(item => DB.getProduct(item.productId));
    const count = cartQuantity(); $$('.cart-count').forEach(el => el.textContent = count); $('#cartDrawerCount').textContent = `${count} ${count === 1 ? 'produs' : 'produse'}`;
    const itemsRoot = $('#cartItems'); if (!itemsRoot) return;
    $('#cartEmpty').hidden = cart.length > 0; $('#cartFooter').hidden = cart.length === 0;
    itemsRoot.innerHTML = cart.map(item => { const product = DB.getProduct(item.productId); return `<article class="cart-item"><img src="${product.image}" alt="${escapeHTML(product.name)}"><div><h3>${escapeHTML(product.name)}</h3><span class="cart-price">${DB.formatCurrency(product.price)}</span><div class="qty-control"><button type="button" data-cart-change="-1" data-id="${product.id}" aria-label="Scade cantitatea">−</button><span>${item.quantity}</span><button type="button" data-cart-change="1" data-id="${product.id}" aria-label="Crește cantitatea">+</button></div></div><button class="cart-remove" type="button" data-cart-remove="${product.id}">Elimină</button></article>`; }).join('');
    const total = cart.reduce((sum, item) => sum + DB.getProduct(item.productId).price * item.quantity, 0); $('#cartSubtotal').textContent = DB.formatCurrency(total);
  }
  function animateCartButton() { const button = $('.cart-button'); button?.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.18)' }, { transform: 'scale(1)' }], { duration: 380, easing: 'ease-out' }); }
  document.addEventListener('click', event => { const button = event.target.closest('[data-add-cart]'); if (button) addToCart(button.dataset.addCart); });
  $('#cartItems')?.addEventListener('click', event => { const change = event.target.closest('[data-cart-change]'); const remove = event.target.closest('[data-cart-remove]'); if (change) changeCart(change.dataset.id, Number(change.dataset.cartChange)); if (remove) { cart = cart.filter(item => item.productId !== remove.dataset.cartRemove); saveCart(); toast('Produs eliminat din coș.'); } });
  renderCart();

  const overlay = $('#pageOverlay'); const drawer = $('#cartDrawer');
  function setCart(open) { drawer?.classList.toggle('open', open); drawer?.setAttribute('aria-hidden', String(!open)); overlay.hidden = !open; requestAnimationFrame(() => overlay.classList.toggle('visible', open)); document.body.classList.toggle('is-locked', open); if (open) setTimeout(() => $('.drawer-close')?.focus(), 200); }
  $('.cart-button')?.addEventListener('click', () => setCart(true)); $('.drawer-close')?.addEventListener('click', () => setCart(false)); $('[data-close-cart]')?.addEventListener('click', () => { setCart(false); $('#catalog')?.scrollIntoView(); }); overlay?.addEventListener('click', () => setCart(false));
  $('#checkoutButton')?.addEventListener('click', () => { setCart(false); toast('Checkout-ul demo este pregătit. Coșul tău a fost salvat.'); });

  // Quick search
  const searchModal = $('#quickSearch'); const searchInput = $('#quickSearchInput');
  function setSearch(open) { searchModal?.classList.toggle('open', open); searchModal?.setAttribute('aria-hidden', String(!open)); document.body.classList.toggle('is-locked', open); if (open) setTimeout(() => searchInput?.focus(), 220); }
  $('.nav-search')?.addEventListener('click', () => setSearch(true)); $('.quick-search-top button')?.addEventListener('click', () => setSearch(false));
  function renderQuickResults(query) {
    const root = $('#quickResults'); if (!root) return;
    if (!query) { root.innerHTML = '<p class="search-hint">Produse populare: <button>căști</button> <button>lampă</button> <button>cană</button></p>'; return; }
    const matches = availableProducts().filter(product => product.name.toLocaleLowerCase('ro').includes(query.toLocaleLowerCase('ro'))).slice(0, 5);
    root.innerHTML = matches.length ? matches.map(product => `<button class="quick-result" type="button" data-search-product="${product.id}"><img src="${product.image}" alt=""><div><span>${escapeHTML(product.name)}</span><small>${DB.formatCurrency(product.price)}</small></div></button>`).join('') : '<p class="search-hint">Niciun rezultat. Încearcă alt termen.</p>';
  }
  searchInput?.addEventListener('input', event => renderQuickResults(event.target.value.trim()));
  $('#quickResults')?.addEventListener('click', event => { const suggestion = event.target.closest('.search-hint button'); const result = event.target.closest('[data-search-product]'); if (suggestion) { searchInput.value = suggestion.textContent; renderQuickResults(suggestion.textContent); } if (result) { setSearch(false); state.query = DB.getProduct(result.dataset.searchProduct).name; $('#catalogSearch').value = state.query; renderCatalog(); $('#catalog').scrollIntoView(); } });

  // Story modal
  const storyModal = $('#storyModal');
  function setStory(open) { storyModal?.classList.toggle('open', open); storyModal?.setAttribute('aria-hidden', String(!open)); document.body.classList.toggle('is-locked', open); }
  $('.story-play')?.addEventListener('click', () => setStory(true)); $$('.modal-x,[data-close-modal]', storyModal).forEach(button => button.addEventListener('click', () => setStory(false))); storyModal?.addEventListener('click', event => { if (event.target === storyModal) setStory(false); });

  // Testimonials
  let testimonialIndex = 0; const testimonialTrack = $('#testimonialTrack'); const testimonialCount = $$('#testimonialTrack blockquote').length;
  function moveTestimonial(next) { testimonialIndex = (next + testimonialCount) % testimonialCount; if (testimonialTrack) testimonialTrack.style.transform = `translateX(-${testimonialIndex * 100}%)`; $('#testimonialIndex').textContent = String(testimonialIndex + 1).padStart(2, '0'); }
  $('#testimonialPrev')?.addEventListener('click', () => moveTestimonial(testimonialIndex - 1)); $('#testimonialNext')?.addEventListener('click', () => moveTestimonial(testimonialIndex + 1));
  let sliderTimer = setInterval(() => moveTestimonial(testimonialIndex + 1), 6500); $('.testimonial-viewport')?.addEventListener('mouseenter', () => clearInterval(sliderTimer));

  // FAQ
  $('#faqAccordion')?.addEventListener('click', event => {
    const button = event.target.closest('.accordion-item>button'); if (!button) return; const item = button.closest('.accordion-item'); const wasOpen = item.classList.contains('open');
    $$('.accordion-item', $('#faqAccordion')).forEach(other => { other.classList.remove('open'); $('button', other).setAttribute('aria-expanded', 'false'); $('use', other)?.setAttribute('href', '#i-plus'); });
    if (!wasOpen) { item.classList.add('open'); button.setAttribute('aria-expanded', 'true'); $('use', button)?.setAttribute('href', '#i-minus'); }
  });

  // Contact & newsletter validation
  const validators = {
    name: input => input.value.trim().length >= 3 ? '' : 'Te rugăm să introduci numele complet.',
    email: input => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value) ? '' : 'Introdu o adresă de email validă.',
    subject: input => input.value ? '' : 'Alege un subiect.',
    message: input => input.value.trim().length >= 10 ? '' : 'Mesajul trebuie să aibă cel puțin 10 caractere.'
  };
  const validateField = input => { const error = validators[input.name]?.(input) || ''; input.classList.toggle('invalid', Boolean(error)); input.setAttribute('aria-invalid', String(Boolean(error))); const holder = input.parentElement.querySelector('.field-error'); if (holder) holder.textContent = error; return !error; };
  $$('#contactForm input,#contactForm select,#contactForm textarea').forEach(input => { input.addEventListener('blur', () => validateField(input)); input.addEventListener('input', () => { if (input.classList.contains('invalid')) validateField(input); }); });
  $('#contactForm')?.addEventListener('submit', event => { event.preventDefault(); const inputs = $$('input,select,textarea', event.currentTarget); if (!inputs.every(validateField)) return toast('Verifică câmpurile marcate.', 'error'); const button = $('button[type="submit"]', event.currentTarget); const original = button.innerHTML; button.disabled = true; button.textContent = 'Se trimite…'; setTimeout(() => { button.disabled = false; button.innerHTML = original; event.currentTarget.reset(); toast('Mulțumim! Mesajul tău a ajuns la noi.'); }, 850); });
  $('#newsletterForm')?.addEventListener('submit', event => { event.preventDefault(); const input = $('input', event.currentTarget); if (!input.checkValidity()) return toast('Introdu o adresă de email validă.', 'error'); input.value = ''; toast('Bine ai venit în The NOVA Letter!'); });

  $('.back-to-top')?.addEventListener('click', () => scrollTo({ top: 0, behavior: 'smooth' }));
  addEventListener('keydown', event => { if (event.key === 'Escape') { setMenu(false); setCart(false); setSearch(false); setStory(false); } });

  // React to data changes in the admin opened in the same or another tab.
  const refreshData = () => { renderFeatured(); renderCategoryFilters(); renderCatalog(); renderCart(); };
  addEventListener('nova:datachange', refreshData); addEventListener('storage', event => { if (Object.values(DB.KEYS).includes(event.key)) refreshData(); });
})();
