/* NOVA Inventory — local-first data layer
   All application state is persisted as structured JSON in localStorage. */
(() => {
  'use strict';

  const KEYS = {
    products: 'nova_products',
    categories: 'nova_categories',
    suppliers: 'nova_suppliers',
    movements: 'nova_movements',
    settings: 'nova_settings',
    seeded: 'nova_seeded_v3'
  };

  const uid = (prefix = 'id') => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
  const read = (key, fallback = []) => {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
    catch (error) { console.warn(`Could not read ${key}`, error); return fallback; }
  };
  const write = (key, value) => {
    localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new CustomEvent('nova:datachange', { detail: { key } }));
    return value;
  };

  function productArt(name, color = '#7c6df2', variant = 0) {
    const initials = name.split(' ').slice(0, 2).map(word => word[0]).join('').toUpperCase();
    const safe = name.replace(/[<>&"']/g, '');
    const shapes = [
      `<path d="M171 112c0-34 26-61 59-61s59 27 59 61v75h-22v-72c0-23-17-41-37-41s-37 18-37 41v72h-22z" fill="#171929"/><rect x="146" y="151" width="47" height="83" rx="22" fill="#2d3048"/><rect x="267" y="151" width="47" height="83" rx="22" fill="#2d3048"/>`,
      `<path d="M186 82h88l16 170H170z" fill="#f7f1e8"/><path d="M203 82c0-24 12-39 27-39s27 15 27 39" fill="none" stroke="#202337" stroke-width="9"/><path d="M184 143h92" stroke="${color}" stroke-width="18"/>`,
      `<rect x="173" y="62" width="114" height="194" rx="25" fill="#25283b"/><circle cx="230" cy="211" r="21" fill="${color}"/><rect x="198" y="91" width="64" height="78" rx="12" fill="#f9f5ed" opacity=".9"/>`,
      `<path d="M168 116h124v104a37 37 0 0 1-37 37h-50a37 37 0 0 1-37-37z" fill="#f6f0e7"/><path d="M292 142h15c30 0 30 57 0 57h-15" fill="none" stroke="#f6f0e7" stroke-width="17"/><path d="M192 116c10-28 29-29 38-52 9 23 28 24 38 52" fill="none" stroke="${color}" stroke-width="10"/>`,
      `<path d="M205 60h50l10 27v34h-70V87z" fill="#f4eee4"/><path d="M184 121h92l23 137H161z" fill="${color}"/><rect x="207" y="142" width="46" height="74" rx="23" fill="#fff" opacity=".72"/>`,
      `<ellipse cx="230" cy="237" rx="105" ry="21" fill="#111424" opacity=".18"/><path d="M149 215c27-55 45-93 81-137 36 44 54 82 81 137-51 27-111 27-162 0" fill="${color}"/><circle cx="230" cy="142" r="29" fill="#fbf7ef" opacity=".8"/>`
    ];
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="460" height="320" viewBox="0 0 460 320"><defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${color}" stop-opacity=".22"/><stop offset="1" stop-color="#f6f3ec"/></linearGradient><filter id="s"><feDropShadow dx="0" dy="12" stdDeviation="12" flood-opacity=".18"/></filter></defs><rect width="460" height="320" rx="28" fill="url(#bg)"/><circle cx="60" cy="54" r="86" fill="${color}" opacity=".10"/><circle cx="408" cy="292" r="112" fill="#fff" opacity=".55"/><g filter="url(#s)">${shapes[variant % shapes.length]}</g><rect x="22" y="22" width="49" height="30" rx="15" fill="#fff" opacity=".75"/><text x="46.5" y="42.5" text-anchor="middle" font-family="Arial,sans-serif" font-size="12" font-weight="700" fill="#292b3b">${initials}</text><title>${safe}</title></svg>`;
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
  }

  const categoriesSeed = [
    { id: 'cat_home', name: 'Home & Living', color: '#f08a68', description: 'Obiecte atent alese pentru o casă care se simte a ta.' },
    { id: 'cat_tech', name: 'Tech', color: '#7467eb', description: 'Tehnologie simplă, elegantă și cu adevărat utilă.' },
    { id: 'cat_wellness', name: 'Wellness', color: '#58a786', description: 'Ritualuri mici pentru starea ta de bine.' },
    { id: 'cat_workspace', name: 'Workspace', color: '#dc9d3e', description: 'Instrumente frumoase pentru idei mai bune.' },
    { id: 'cat_outdoor', name: 'Outdoor', color: '#3d8f9d', description: 'Esențiale durabile pentru zile în aer liber.' },
    { id: 'cat_accessories', name: 'Accesorii', color: '#b3658c', description: 'Detalii expresive, create să dureze.' }
  ];

  const suppliersSeed = [
    { id: 'sup_nord', name: 'Nord Atelier', contact: 'Mara Stan', email: 'hello@nordatelier.ro', phone: '+40 721 460 112', city: 'Cluj-Napoca', status: 'active' },
    { id: 'sup_form', name: 'Form & Function', contact: 'Radu Ene', email: 'orders@formfunction.eu', phone: '+40 733 140 810', city: 'București', status: 'active' },
    { id: 'sup_senso', name: 'Senso Goods', contact: 'Ioana Dima', email: 'office@sensogoods.ro', phone: '+40 742 890 221', city: 'Iași', status: 'active' },
    { id: 'sup_mono', name: 'Mono Supply Co.', contact: 'Victor Toma', email: 'trade@monosupply.com', phone: '+40 756 114 090', city: 'Timișoara', status: 'active' },
    { id: 'sup_green', name: 'Green Origin', contact: 'Daria Pop', email: 'contact@greenorigin.ro', phone: '+40 728 772 441', city: 'Brașov', status: 'active' },
    { id: 'sup_arc', name: 'Arc Objects', contact: 'Paul Ionescu', email: 'stock@arcobjects.eu', phone: '+40 720 443 591', city: 'Oradea', status: 'paused' }
  ];

  const rawProducts = [
    ['Căști Aura Studio','NVA-1001','cat_tech','sup_form',699,34,8,214,'#7667e8',0,true],
    ['Lampă Halo Mini','NVA-1002','cat_home','sup_nord',349,7,10,148,'#ef8b6c',4,true],
    ['Difuzor Moss S2','NVA-1003','cat_tech','sup_form',479,0,6,92,'#5a9b82',2,true],
    ['Cană ceramică Nami','NVA-1004','cat_home','sup_senso',89,62,12,310,'#d69b45',3,true],
    ['Set îngrijire Solace','NVA-1005','cat_wellness','sup_senso',219,18,7,164,'#5ca98d',4,true],
    ['Geantă Loop Canvas','NVA-1006','cat_accessories','sup_mono',269,25,6,127,'#aa6589',1,true],
    ['Tastatură Forma 75','NVA-1007','cat_workspace','sup_form',589,11,5,106,'#7c6df2',0,true],
    ['Sticlă termică Roam','NVA-1008','cat_outdoor','sup_green',139,46,10,205,'#3f929f',2,false],
    ['Agendă Dot Grid A5','NVA-1009','cat_workspace','sup_nord',74,85,15,402,'#d79d42',1,false],
    ['Ceas de masă Mono','NVA-1010','cat_home','sup_mono',189,13,5,119,'#6d7085',5,false],
    ['Boxă portabilă Pebble','NVA-1011','cat_tech','sup_form',399,5,7,193,'#5c7ed5',2,true],
    ['Lumânare Cedar No. 4','NVA-1012','cat_wellness','sup_senso',119,38,9,244,'#a36b52',4,false],
    ['Rucsac Field 18L','NVA-1013','cat_outdoor','sup_green',429,16,5,101,'#487e72',1,true],
    ['Suport laptop Arc','NVA-1014','cat_workspace','sup_mono',239,29,8,175,'#9a735b',5,false],
    ['Tavă din stejar Lune','NVA-1015','cat_home','sup_nord',179,9,9,87,'#bd744d',3,false],
    ['Ulei facial Dew','NVA-1016','cat_wellness','sup_senso',159,3,8,221,'#73aa8c',4,true],
    ['Cablu Loop USB-C','NVA-1017','cat_tech','sup_form',99,71,12,349,'#7164c9',5,false],
    ['Ochelari Nomad','NVA-1018','cat_accessories','sup_mono',319,14,6,83,'#aa6486',0,false],
    ['Pătură Woven Sage','NVA-1019','cat_home','sup_nord',329,22,6,118,'#718f79',1,true],
    ['Set pixuri Flux','NVA-1020','cat_workspace','sup_nord',129,4,10,192,'#d39842',2,false],
    ['Kit picnic Terra','NVA-1021','cat_outdoor','sup_green',499,8,4,64,'#c36e53',3,false],
    ['Portofel Fold Slim','NVA-1022','cat_accessories','sup_arc',199,31,7,98,'#8d677c',1,false],
    ['Încărcător Orbit 3-in-1','NVA-1023','cat_tech','sup_form',299,12,5,156,'#596bca',2,true],
    ['Pernă Linen Cloud','NVA-1024','cat_home','sup_nord',149,27,8,139,'#c47f6a',3,false],
    ['Roller parfum Still','NVA-1025','cat_wellness','sup_senso',109,0,5,176,'#69a789',4,false],
    ['Husă laptop Soft Grid','NVA-1026','cat_accessories','sup_mono',179,19,7,88,'#9c6682',1,false]
  ];

  const descriptions = {
    cat_home: 'Formă tactilă, materiale naturale și o prezență calmă pentru spațiul tău.',
    cat_tech: 'Performanță intuitivă într-un obiect precis, discret și ușor de folosit.',
    cat_wellness: 'O formulă atent construită pentru un ritual zilnic simplu și reconfortant.',
    cat_workspace: 'Creat pentru concentrare, confort și un birou în care îți place să revii.',
    cat_outdoor: 'Rezistent, compact și pregătit pentru ritmul zilelor petrecute afară.',
    cat_accessories: 'Un detaliu versatil, finisat cu grijă și gândit pentru utilizare zilnică.'
  };

  const productsSeed = rawProducts.map((p, index) => ({
    id: `prd_${String(index + 1).padStart(3, '0')}`,
    name: p[0], sku: p[1], categoryId: p[2], supplierId: p[3], price: p[4], quantity: p[5], minStock: p[6], sales: p[7], color: p[8], featured: p[10],
    description: descriptions[p[2]], image: productArt(p[0], p[8], p[9]),
    createdAt: new Date(2026, (index * 3) % 10, ((index * 7) % 27) + 1).toISOString(), updatedAt: new Date(2026, 9, ((index * 5) % 24) + 1).toISOString()
  }));

  function makeMovements() {
    const reasonsIn = ['Recepție furnizor', 'Retur client', 'Corecție inventar'];
    const reasonsOut = ['Vânzare online', 'Vânzare showroom', 'Mostră / protocol', 'Pierdere'];
    return Array.from({ length: 34 }, (_, index) => {
      const product = productsSeed[(index * 7) % productsSeed.length];
      const type = index % 3 === 0 ? 'in' : 'out';
      const daysAgo = index % 24;
      const date = new Date(2026, 9, 24 - daysAgo, 9 + (index % 8), (index * 11) % 60);
      return {
        id: `mov_${String(index + 1).padStart(3, '0')}`,
        productId: product.id,
        type,
        quantity: type === 'in' ? 8 + (index % 15) : 1 + (index % 6),
        reason: type === 'in' ? reasonsIn[index % reasonsIn.length] : reasonsOut[index % reasonsOut.length],
        user: index % 4 === 0 ? 'Andrei M.' : index % 4 === 1 ? 'Mara D.' : index % 4 === 2 ? 'Ioana P.' : 'Sistem',
        date: date.toISOString(),
        note: index % 5 === 0 ? 'Verificat și aprobat' : ''
      };
    }).sort((a, b) => new Date(b.date) - new Date(a.date));
  }

  function seed(force = false) {
    if (!force && localStorage.getItem(KEYS.seeded)) return;
    write(KEYS.categories, categoriesSeed);
    write(KEYS.suppliers, suppliersSeed);
    write(KEYS.products, productsSeed);
    write(KEYS.movements, makeMovements());
    write(KEYS.settings, { currency: 'RON', storeName: 'NOVA Living', lowStockNotifications: true, weeklyReport: true });
    localStorage.setItem(KEYS.seeded, 'true');
  }

  seed();

  const collection = (name) => read(KEYS[name], []);
  const saveCollection = (name, items) => write(KEYS[name], items);

  const api = {
    KEYS,
    uid,
    seed,
    reset: () => seed(true),
    getProducts: () => collection('products'),
    getCategories: () => collection('categories'),
    getSuppliers: () => collection('suppliers'),
    getMovements: () => collection('movements'),
    getSettings: () => read(KEYS.settings, {}),
    getProduct: id => collection('products').find(item => item.id === id),
    getCategory: id => collection('categories').find(item => item.id === id),
    getSupplier: id => collection('suppliers').find(item => item.id === id),
    saveSettings: settings => write(KEYS.settings, { ...read(KEYS.settings, {}), ...settings }),
    addProduct(data) {
      const items = collection('products');
      const product = { id: uid('prd'), sales: 0, featured: false, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), color: data.color || '#7467eb', image: data.image || productArt(data.name, data.color || '#7467eb', items.length), ...data, price: Number(data.price), quantity: Number(data.quantity), minStock: Number(data.minStock) };
      items.unshift(product); saveCollection('products', items);
      if (product.quantity > 0) api.addMovement({ productId: product.id, type: 'in', quantity: product.quantity, reason: 'Stoc inițial', user: 'Andrei M.', updateStock: false });
      return product;
    },
    updateProduct(id, data) {
      const items = collection('products');
      const index = items.findIndex(item => item.id === id);
      if (index < 0) return null;
      items[index] = { ...items[index], ...data, price: Number(data.price ?? items[index].price), quantity: Number(data.quantity ?? items[index].quantity), minStock: Number(data.minStock ?? items[index].minStock), updatedAt: new Date().toISOString() };
      saveCollection('products', items); return items[index];
    },
    deleteProducts(ids) {
      const idSet = new Set(Array.isArray(ids) ? ids : [ids]);
      saveCollection('products', collection('products').filter(item => !idSet.has(item.id)));
      saveCollection('movements', collection('movements').filter(item => !idSet.has(item.productId)));
    },
    addMovement(data) {
      const product = api.getProduct(data.productId);
      if (!product) throw new Error('Produsul nu există.');
      const quantity = Math.max(1, Number(data.quantity));
      if (data.type === 'out' && data.updateStock !== false && product.quantity < quantity) throw new Error('Cantitatea depășește stocul disponibil.');
      if (data.updateStock !== false) api.updateProduct(product.id, { quantity: product.quantity + (data.type === 'in' ? quantity : -quantity) });
      const movement = { id: uid('mov'), productId: product.id, type: data.type, quantity, reason: data.reason, user: data.user || 'Andrei M.', note: data.note || '', date: data.date || new Date().toISOString() };
      const items = collection('movements'); items.unshift(movement); saveCollection('movements', items); return movement;
    },
    upsertCategory(data, id = null) {
      const items = collection('categories');
      if (id) {
        const index = items.findIndex(item => item.id === id); if (index < 0) return null;
        items[index] = { ...items[index], ...data }; saveCollection('categories', items); return items[index];
      }
      const item = { id: uid('cat'), color: '#7467eb', description: '', ...data }; items.push(item); saveCollection('categories', items); return item;
    },
    deleteCategory(id) {
      if (collection('products').some(product => product.categoryId === id)) throw new Error('Categoria are produse asociate și nu poate fi ștearsă.');
      saveCollection('categories', collection('categories').filter(item => item.id !== id));
    },
    upsertSupplier(data, id = null) {
      const items = collection('suppliers');
      if (id) {
        const index = items.findIndex(item => item.id === id); if (index < 0) return null;
        items[index] = { ...items[index], ...data }; saveCollection('suppliers', items); return items[index];
      }
      const item = { id: uid('sup'), status: 'active', ...data }; items.push(item); saveCollection('suppliers', items); return item;
    },
    deleteSupplier(id) {
      if (collection('products').some(product => product.supplierId === id)) throw new Error('Furnizorul are produse asociate și nu poate fi șters.');
      saveCollection('suppliers', collection('suppliers').filter(item => item.id !== id));
    },
    getStockStatus(product) {
      if (product.quantity <= 0) return 'out';
      if (product.quantity <= product.minStock) return 'low';
      return 'ok';
    },
    productArt,
    formatCurrency(value) { return new Intl.NumberFormat('ro-RO', { style: 'currency', currency: 'RON', maximumFractionDigits: 0 }).format(value); },
    exportFile(filename, data, mime = 'application/json') {
      const blob = new Blob([data], { type: `${mime};charset=utf-8` });
      const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = filename; document.body.appendChild(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(link.href), 500);
    }
  };

  window.InventoryDB = api;
})();
