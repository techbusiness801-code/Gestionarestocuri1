# NOVA Living + NOVA Inventory

Website public și aplicație de administrare a stocurilor, construite integral cu **HTML, CSS și JavaScript vanilla**. Datele sunt locale, persistente și sincronizate între cele două interfețe prin `localStorage`.

## Pornire

Nu există build step sau dependențe de instalat. Din rădăcina proiectului:

```bash
python3 -m http.server 8080
```

Apoi deschide:

- Magazin: [http://localhost:8080/index.html](http://localhost:8080/index.html)
- Admin: [http://localhost:8080/admin.html](http://localhost:8080/admin.html)

Poți deschide și fișierele direct în browser, însă un server local este recomandat pentru un comportament consecvent al resurselor.

## Structură

```text
.
├── index.html                 # storefront public
├── admin.html                 # aplicație SaaS de inventar
├── css/
│   ├── style.css              # design system + website public
│   └── admin.css              # dashboard și componente admin
├── js/
│   ├── data.js                # seed, CRUD, localStorage și export
│   ├── main.js                # catalog, coș, formulare, interacțiuni
│   ├── admin.js               # dashboard, produse, stocuri, rapoarte
│   └── vendor/chart.umd.min.js
└── assets/
    ├── fonts/                 # DM Sans + Manrope, locale
    └── novastock-hero.jpg
```

## Date și persistență

La prima rulare, `js/data.js` populează automat:

- 26 produse realiste;
- 6 categorii;
- 6 furnizori;
- 34 mișcări de stoc.

Cheile principale sunt `nova_products`, `nova_categories`, `nova_suppliers`, `nova_movements`, `nova_settings`, `nova_cart` și `nova_theme`. Resetarea completă este disponibilă în **Admin → Setări**.

> Datele sunt specifice browserului și originii. Pentru a vedea modificările instant în magazin și admin, deschide ambele pagini pe aceeași adresă locală.

## Funcționalități principale

### Admin

- Dashboard cu KPI-uri, 3 grafice Chart.js, activitate și alerte;
- CRUD produse, categorii și furnizori;
- căutare, filtre (categorie, status, preț), sortare și paginare;
- upload imagine cu preview, validare SKU, selectare multiplă;
- export CSV/JSON;
- intrări/ieșiri cu motiv, note și validarea cantității;
- istoric complet per produs și jurnal global;
- rapoarte pe zi/săptămână/lună/perioadă custom;
- căutare globală, notificări dinamice, modale și toast-uri;
- dark/light mode și layout responsive.

### Magazin

- landing page premium și complet responsive;
- catalog live sincronizat cu inventarul;
- căutare, filtrare, sortare și încărcare progresivă;
- coș persistent cu controlul cantităților;
- căutare rapidă, favorite și stări de stoc;
- testimoniale, FAQ, jurnal, formular de contact și newsletter;
- animații la scroll, counters, micro-interacțiuni și mod dark/light;
- navigare accesibilă, focus states și suport pentru `prefers-reduced-motion`.

## Note

- Chart.js este inclus local, nu prin CDN, pentru funcționare offline.
- Fonturile sunt servite local pentru ca preview-ul să nu depindă de resurse externe.
- Aplicația este un demo complet front-end; checkout-ul și trimiterea formularelor sunt simulate vizual.
